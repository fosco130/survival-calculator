var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var get_standings_exports = {};
__export(get_standings_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_standings_exports);
const FOOTBALL_DATA_API = "https://api.football-data.org/v4/competitions/PL/standings";
const CACHE_TTL = 36e5;
let cachedData = null;
let cacheTime = null;
async function fetchStandings() {
  const apiKey = process.env.FOOTBALL_DATA_API_KEY;
  if (!apiKey) {
    throw new Error("FOOTBALL_DATA_API_KEY environment variable is not set");
  }
  try {
    const response = await fetch(FOOTBALL_DATA_API, {
      headers: {
        "X-Auth-Token": apiKey
      }
    });
    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }
    const data = await response.json();
    return transformStandingsData(data);
  } catch (error) {
    console.error("Error fetching standings:", error);
    throw error;
  }
}
function transformStandingsData(rawData) {
  const standingsData = rawData.standings.find((s) => s.type === "TOTAL");
  if (!standingsData) {
    throw new Error("No TOTAL standings data found");
  }
  const teams = standingsData.table.map((entry) => ({
    id: entry.team.id,
    name: entry.team.name,
    shortName: entry.team.shortName,
    crest: entry.team.crest,
    // Include club crest URL from API
    position: entry.position,
    points: entry.points,
    playedGames: entry.playedGames,
    won: entry.won,
    draw: entry.draw,
    lost: entry.lost,
    goalsFor: entry.goalsFor,
    goalsAgainst: entry.goalsAgainst,
    goalDifference: entry.goalDifference
  }));
  return {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    teams
  };
}
const handler = async (event, context) => {
  if (cachedData && cacheTime && Date.now() - cacheTime < CACHE_TTL) {
    console.log("Returning cached standings data");
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=3600",
        "X-Cache-Status": "HIT"
      },
      body: JSON.stringify(cachedData)
    };
  }
  try {
    const standings = await fetchStandings();
    cachedData = standings;
    cacheTime = Date.now();
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=3600",
        "X-Cache-Status": "MISS"
      },
      body: JSON.stringify(standings)
    };
  } catch (error) {
    console.error("Error in get-standings function:", error);
    if (cachedData) {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "public, max-age=60",
          "X-Cache-Status": "STALE",
          "X-Error": "Using stale cache due to API error"
        },
        body: JSON.stringify(cachedData)
      };
    }
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        error: "Failed to fetch standings data",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
