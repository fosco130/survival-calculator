var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var get_fixtures_exports = {};
__export(get_fixtures_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_fixtures_exports);
const FOOTBALL_DATA_API = "https://api.football-data.org/v4/competitions/PL/matches?status=SCHEDULED";
const CACHE_TTL = 36e5;
let cachedData = null;
let cacheTime = null;
async function fetchFixtures() {
  const apiKey = process.env.FOOTBALL_DATA_API_KEY;
  if (!apiKey) {
    throw new Error("FOOTBALL_DATA_API_KEY environment variable is not set");
  }
  try {
    const response = await fetch(FOOTBALL_DATA_API, {
      headers: {
        "X-Auth-Token": apiKey
      }
    });
    if (!response.ok) {
      throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }
    const data = await response.json();
    return transformFixturesData(data);
  } catch (error) {
    console.error("Error fetching fixtures:", error);
    throw error;
  }
}
function transformFixturesData(rawData) {
  const fixtures = rawData.matches.filter((match) => match.status === "SCHEDULED").map((match) => ({
    id: match.id,
    utcDate: match.utcDate,
    status: match.status,
    stage: match.stage,
    homeTeam: {
      id: match.homeTeam.id,
      name: match.homeTeam.name,
      shortName: match.homeTeam.shortName
    },
    awayTeam: {
      id: match.awayTeam.id,
      name: match.awayTeam.name,
      shortName: match.awayTeam.shortName
    }
  })).sort((a, b) => new Date(a.utcDate) - new Date(b.utcDate));
  return {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    count: fixtures.length,
    fixtures
  };
}
const handler = async (event, context) => {
  if (cachedData && cacheTime && Date.now() - cacheTime < CACHE_TTL) {
    console.log("Returning cached fixtures data");
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=3600",
        "X-Cache-Status": "HIT"
      },
      body: JSON.stringify(cachedData)
    };
  }
  try {
    const fixtures = await fetchFixtures();
    cachedData = fixtures;
    cacheTime = Date.now();
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "public, max-age=3600",
        "X-Cache-Status": "MISS"
      },
      body: JSON.stringify(fixtures)
    };
  } catch (error) {
    console.error("Error in get-fixtures function:", error);
    if (cachedData) {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "public, max-age=60",
          "X-Cache-Status": "STALE",
          "X-Error": "Using stale cache due to API error"
        },
        body: JSON.stringify(cachedData)
      };
    }
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        error: "Failed to fetch fixtures data",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
